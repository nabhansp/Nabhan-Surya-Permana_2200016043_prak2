import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('staxk'),
          backgroundColor: Color.fromARGB(255, 28, 79, 120),
        ),
        body: Center(
          child: Stack(
            children: <Widget>[
              Align(
                  alignment: Alignment.center,
                  child: Container(
                    color: Color.fromARGB(255, 4, 205, 246),
                    height: 100,
                    width: 100,
                  )),
              Align(
                  alignment: Alignment.center,
                  child: Container(
                    color: Colors.blue,
                    height: 100,
                    width: 80,
                    margin: EdgeInsets.only(top: 20),
                  )),
              Align(
                  alignment: Alignment.center,
                  child: Container(
                    color: Colors.purple,
                    height: 70,
                    width: 70,
                    margin: EdgeInsets.only(top: 20),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
